import { exec } from "child_process";
import express from "express";

function run(cmd) {
  return new Promise((resolve) => {
    exec(cmd, { shell: "/bin/bash" }, (err, stdout, stderr) => {
      resolve({ ok: !err, stdout: stdout?.trim(), stderr: stderr?.trim(), error: err?.message });
    });
  });
}

export function serviceRouter({ MODE }) {
  const router = express.Router();

  router.get("/status", async (req, res) => {
    if (MODE === "local") {
      // simulate status toggling
      return res.json({ status: "active" });
    }
    const r = await run("systemctl is-active mutimax || true");
    res.json({ status: r.stdout || "unknown" });
  });

  router.post("/start", async (req, res) => {
    if (MODE === "local") return res.json({ ok: true, message: "started (simulado)" });
    const r = await run("sudo systemctl start mutimax");
    res.json({ ok: r.ok, stdout: r.stdout, stderr: r.stderr, error: r.error });
  });

  router.post("/stop", async (req, res) => {
    if (MODE === "local") return res.json({ ok: true, message: "stopped (simulado)" });
    const r = await run("sudo systemctl stop mutimax");
    res.json({ ok: r.ok, stdout: r.stdout, stderr: r.stderr, error: r.error });
  });

  router.post("/restart", async (req, res) => {
    if (MODE === "local") return res.json({ ok: true, message: "restarted (simulado)" });
    const r = await run("sudo systemctl restart mutimax");
    res.json({ ok: r.ok, stdout: r.stdout, stderr: r.stderr, error: r.error });
  });

  return router;
}
